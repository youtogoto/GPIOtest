/*******************************************************************
    my_button.h
       
    Button control library

*******************************************************************/

#ifndef _MY_BUTTON_H_
#define _MY_BUTTON_H_

//=====================================
// Initialize button
//=====================================
void init_button();

//=====================================
// Get button status(On or Off)
//=====================================
int get_button_status(); // return: 1->Button Pushed  0->Button Released

#endif

