/*******************************************************************
    my_led_button.h
       
    LED/Button control library

*******************************************************************/

#ifndef _MY_LED_BUTTONH_
#define _MY_LED_BUTTONH_


//=====================================
// LED class library
//=====================================
class my_led
{
private:
    uint32_t    io_pin;
    uint32_t    brightness;
    uint32_t    da_ch;
    uint32_t    on_off_status;

    uint32_t    _calc_duty(uint32_t value);
    void        _pwm_write(uint32_t ch, uint32_t br);
    void        _update();
    
public:
    my_led(uint32_t pin, uint32_t ch);

    // Set LED brightness 
    void    set_brightness(uint32_t br);
    // Turn on/off LED
    void    turn(uint32_t on_off);
    // Toggle between on and off
    void    toggle();
    // Get LED status(On or Off)
    uint32_t get_status();
};


//=====================================
// Button class library
//=====================================
class my_button
{
private:
    uint32_t io_pin;
    
public:
    my_button(uint32_t pin);

    // Attach interrupt service routine
    void attach_isr(void (*isr)(void), uint32_t mode);
    // Get button status(On or Off)
    uint32_t get_status(); // return: 1->Button Pushed  0->Button Released
    
};


#endif
