/*******************************************************************
    my_led_button.cpp
       
    LED/Button control library

*******************************************************************/
#include <Arduino.h>

#include <my_led_button.h>


// use 5000 Hz as a LEDC base frequency
#define LEDC_BASE_FREQ 5000
// use 13 bit precission for LEDC timer
#define LEDC_BIT 13

//////////////////////////////////////////////////////////////////
// my_led class
//////////////////////////////////////////////////////////////////

//================================================
// Constructor
//================================================
my_led::my_led(uint32_t pin, uint32_t ch)
{
    io_pin = pin;
    da_ch = ch;
    brightness = 255; // Max

    // setup for ESP32
    pinMode(io_pin, OUTPUT);
    ledcSetup(da_ch, LEDC_BASE_FREQ, LEDC_BIT); // 5000 Hz as a LEDC base frequency
    ledcAttachPin(io_pin, da_ch);

    // LED off
    turn(0);
}

//================================================
// Set LED brightness 
//================================================
void my_led::set_brightness(uint32_t br) // br:0-255
{
    brightness = br>255 ? 255 : br;
    _update();
}

//================================================
// Turn on/off LED
//================================================
void my_led::turn(uint32_t on_off) // on_off: 0->off  1->on
{
    on_off_status = on_off;
    _update();
}

//================================================
// Toggle between on and off
//================================================
void my_led::toggle()
{
    on_off_status = on_off_status ? 0 : 1;
    _update();
}

//================================================
// [Private]
// Calcurate duty ratio from calue(0-255)
//================================================
uint32_t my_led::_calc_duty(uint32_t value)
{
    value = value>255 ? 255 : value;
    // calculate duty, 8191 from 2 ^ 13 - 1
    return (((1<<LEDC_BIT)-1) / 255) * value;
}

//================================================
// [Private]
// Output PWM pulse to the channel
//================================================
void my_led::_pwm_write(uint32_t ch, uint32_t br) 
{
    uint32_t duty = _calc_duty(br);

    // write duty to LEDC
    ledcWrite(ch, duty);
}

//================================================
// [Private]
// Update LED status
//================================================
void my_led::_update()
{
    if(on_off_status) { 
        _pwm_write(da_ch, brightness);    // turn on LED.
    }
    else {
        _pwm_write(da_ch, 0);     // turn off LED.
    }
}

//================================================
// Get LED status(On or Off)
//================================================
uint32_t my_led::get_status() // return : 0->Off, not zero->On 
{
    return on_off_status;
}


//////////////////////////////////////////////////////////////////
// my_button class
//////////////////////////////////////////////////////////////////

//================================================
// Constructor
//================================================
my_button::my_button(uint32_t pin)
{
    io_pin = pin;
    pinMode(io_pin, INPUT);
}

//================================================
// Attach interrupt service routine
//================================================
void my_button::attach_isr(void (*isr)(void), uint32_t mode)
{
    attachInterrupt(io_pin, isr, mode);
}

//================================================
// Get button status(On or Off)
//================================================
uint32_t my_button::get_status()
{
	uint32_t button_status = digitalRead(io_pin);
    if(button_status == 0) { // If button is pushed
        return  1;
    }
    else {
        return  0;
    }
}

