// MPU-6050 Accelerometer + Gyro

void MPU6050_init(TwoWire* pWire);

int MPU6050_get_all(
		float* p_acc_x,
		float* p_acc_y,
		float* p_acc_z,
		float* p_gyro_x,
		float* p_gyro_y,
		float* p_gyro_z,
		float* p_temperature);

int MPU6050_read(int start, uint8_t *buffer, int size) ;

int MPU6050_write(int start, const uint8_t *pData, int size);
int MPU6050_write_reg(int reg, uint8_t data);
