#ifndef _MY_CMD_H_
#define _MY_CMD_H_


// Command information structure
struct _command_info{
    char*   cmd;
    void    (*proc)(int argc, char* argv[]);
};
typedef struct _command_info T_command_info;


// Parse commandline
//    cmdline  : Commandline string
//    argv     : Result of parsing
//  return value : Number of arguments
int parse_cmdline(char* cmdline, char* argv[]);

// Parse commandline
//    cmdline    : Commandline string
//    cmd_table  : Table of command information
//  return value : 0:Error(command wasn't found)  1:Success
int parse_and_exec_cmd(char* cmdline, T_command_info cmd_table[]);

#endif

