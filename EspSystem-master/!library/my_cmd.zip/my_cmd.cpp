#include "string.h"
#include "my_cmd.h"

int parse_cmdline(char* cmd_line, char* argv[])
{
    int argc = 0;
    char* p = NULL;
    char* str = cmd_line;
    while(1) {
        p = strtok(str, " ");
        if(p != NULL){
            str = NULL;
            argv[argc] = p;
            argc ++;
        }
        else {
            break;
        }
    }
    
    return  argc;
}

int parse_and_exec_cmd(char* cmdline, T_command_info cmd_table[])
{
    // Parse command line
    char* argv[10];
    int argc = parse_cmdline(cmdline, argv);

    // Search cmd_table and execute the command
    if(argc > 0) {
        for(int i = 0; ; i ++) {
            if(cmd_table[i].cmd != NULL) {
                if(strcmp(argv[0], cmd_table[i].cmd) == 0) {
                    // Find a command in the cmd_table
                    cmd_table[i].proc(argc, argv);
                    break;
                }
            }
            else {
                // The last line
                return 0;
            }
        }
    }
    
    return  1;
}

